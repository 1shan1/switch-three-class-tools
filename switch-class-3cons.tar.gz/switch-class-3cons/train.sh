export PYTHONPATH=./:/home/pengshanzhen/caffe/python:$PYTHONPATH
LOG=/data_2/my_bishe_experiment/switch_classification_3concats/snapshot-b/log-`date +%Y-%m-%d-%H-%M-%S`.log 
/home/pengshanzhen/caffe/build/tools/caffe train -solver solver.prototxt -weights /data_2/my_bishe_experiment/switch_classification_3concats/b-model_iter_8000.caffemodel  2>&1  | tee $LOG $@






